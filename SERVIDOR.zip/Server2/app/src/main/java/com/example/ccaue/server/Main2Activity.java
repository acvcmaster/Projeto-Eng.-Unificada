
public class Main2Activity extends AppCompatActivity {

    String[] users = {"usuario 1", "usuario 2", "usuario 3"};
    ArrayAdapter<String> adapter;
    ListView List;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        List = (ListView) findViewById(R.id.List);

        adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,users);
        List.setAdapter(adapter);
    }

}
